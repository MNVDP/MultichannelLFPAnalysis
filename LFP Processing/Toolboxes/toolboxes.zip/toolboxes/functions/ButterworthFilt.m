%% Butterworth Filter for SplicedData
% Go through each Channel and filter each individually

function [SplicedData] = ButterworthFilt( SplicedData, ftype, filterOrder, cutOffFreq, sampleRate)

  %% Filter data
    % See http://au.mathworks.com/help/signal/ug/filtering-data-with-signal-processing-toolbox.html
    % Also 
    % Low pass FIR filter
    
    % Normalise data (see
    % http://www.dataminingblog.com/standardization-vs-normalization/) This
    % for the (x - min(x))/max(x)-min(x) bit... subtracting the mean is so
    % the data is around 0 so I can filter it properly, normalising it made
    % it between 0 and 1 not around 0.

    % 18/01/2016
    x = SplicedData;
    y = 1:length(x);
%     NormLFP = (x - min(x))/(max(x) - min(x));
    xmean = mean(x);   
    for blah = 1:length(x);
        x(1, blah) = x(1, blah) - xmean;
    end
    
%% High pass 1Hz Filter (Butterworth) % not sure if working as intended.
if ftype ==1;
    ftype = 'low';

elseif ftype == 2;
%     filterOrder = 2; % 6th order butterworth filter
ftype = 'high';
else
    fprintf('Error specifying filter type');
end
% cutOffFreq = 0.5; %Hz

[b,a] = butter(filterOrder,cutOffFreq/(sampleRate/2), ftype);
%freqz(b,a); %Automated plotting suppressed
dataIn = x;
dataOut = filtfilt(b,a,dataIn); % If you want zero phase lag use filtfilt instead of filter

    for blah = 1:length(x);
        dataOut(1, blah) = dataOut(1, blah) + xmean;
    end

SplicedData(:, :) = dataOut(:,:);

end
