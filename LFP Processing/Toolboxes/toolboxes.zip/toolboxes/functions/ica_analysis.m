function [ICAFiltLFP1, min_vals,icasig1,A1,WA1] = ica_analysis(LFP,num_components)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% Edited to include an output argument for num_components
% ICA correct data
% LFP_pre=LFP;

%% NOTES
% 25/02/2020 RJ Added a second output argument to the function to return
% the ICA weights. The variable is defined on line 37.
% 27/02/2020 RJ Added extra output arguments for different ICA steps
% (icasig1,A1,WA1)

% ICA CORRECT
switch 1
    case 1
        icasig1=[];A1=[];
        [icasig1, A1, WA1] = fastica(LFP, 'numOfIC' ,num_components);
        ICvalues=[];
        
        ch = 1:size(LFP,1);
        for BRP=1:size(A1,2)
            if sum(A1(:,BRP)<-1)>=length(ch)-0 || sum(A1(:,BRP)>1)>=length(ch)-0
                ICvalues(BRP)=BRP;
            else
                ICvalues(BRP)=NaN;
            end
        end
        ICVfly1=ICvalues(~isnan(ICvalues));
        ICAFiltLFP=[];
        for chan=1:size(LFP,1)
            ValuesMin=[];
            for YH=1:length(ICVfly1)
                ValuesMin(YH,:)=A1(chan,ICVfly1(YH))*icasig1(ICVfly1(YH),:);
            end
            if isempty(ValuesMin)==1;ValuesMin=zeros(size(LFP,2),1)';end;
            
            ICAFiltLFP(chan,:)=LFP(ch(chan),:)-sum(ValuesMin,1);
            min_vals(chan,:) = sum(ValuesMin,1);
        end
end

ICAFiltLFP1 = ICAFiltLFP;


end

