function [SplicedData] = DriftRemoval( SplicedData, Dir, FolderName )
%BaselineCorrect
%   This function uses a moving window to correct the baseline at every
%   point by subtracting the median within a 2 second window.
%   This can correct drifts from baseline in the recording.
%   For a data matrix in the form channel x samples, for every point
%   in the sample the function will compute the median across each channel
%   in a 2 second window. For instance, for point x, the median computed
%   for each channel will be [x:x+2000 frames] for a 1000Hz sampling rate.

WindowWidth = 2000; %sample rate is 1000 so 2000 is 2 seconds
MedianSubtracted = zeros(size(SplicedData, 1), length(SplicedData));

count = 0;
for i = 1:WindowWidth:length(SplicedData);
    %     for Chan = 1:16;
    try
        MedianVal = median(SplicedData(:, i:(i+WindowWidth)),2);
        MedianSubtracted(:,i:(i+WindowWidth)) = bsxfun(@minus,SplicedData(:,i:i+WindowWidth),MedianVal); % BaselineSubtracted
        
    catch
        MedianVal = MedianVal; % For the last segments subtract the median from the previous 2 s from it.
        MedianSubtracted(:,i:length(SplicedData)) = bsxfun(@minus,SplicedData(:,i:length(SplicedData)),MedianVal); % BaselineSubtracted
        
    end
    count = count+1;
    if count == 1000000;
        fprintf(['At ' num2str(i) ' of ' num2str(length(SplicedData)) '.\n']);
        count = 0;
    end
    %     end
end

SplicedData = MedianSubtracted;

% Save in subdirectory. This is based off Dror's code.
if ~isdir([Dir FolderName '/' 'SplicedDataDriftCorrect'])
    mkdir([Dir FolderName '/' 'SplicedDataDriftCorrect']);
end

save([Dir FolderName '/SplicedDataDriftCorrect/SplicedData.mat'], 'SplicedData', 'MedianSubtracted');

%% This is the other version. This is not as precise but takes a lot less time. This is here for my record more than anything.
switch 0
    case 1
        MovingWindowStart = 1:WindowWidth:length(SplicedData);
        MovingWindowEnd = MovingWindowStart-1;
        
        
        Data = struct;
        
        %Make structure containing each 2 second segment of data
        for MovingWindow = 1:length(MovingWindowStart);
            try
                Data(MovingWindow).TwoSecWin = SplicedData(:,MovingWindowStart(1,MovingWindow):MovingWindowEnd(1,MovingWindow+1));
            catch
                Data(MovingWindow).TwoSecWin = SplicedData(:,MovingWindowStart(1,end):length(SplicedData));
            end
        end
        
        %Get the median for each channel for every 2 seconds of data
        for SelectWindow = 1:length(Data);
            for Chan = 1:16;
                Data(SelectWindow).TwoSecMedian(Chan,:) = median(Data(SelectWindow).TwoSecWin(Chan,:));
            end
        end
        
        %Subtract the median for each channel for each 2 second window from the 2
        %second window of data
        for SelectWindow = 1:length(Data);
            for Chan = 1:16;
                for LengthWin = 1:length(Data(SelectWindow).TwoSecWin(1,:));
                    Data(SelectWindow).MedianCorrected(Chan,LengthWin) = Data(SelectWindow).TwoSecWin(Chan,LengthWin) - Data(SelectWindow).TwoSecMedian(Chan,1);
                end
            end
        end
        
        % Append Data back into a Matrix
        BaselineCorrectedData = horzcat(Data(1:length(Data)).MedianCorrected);
        
        SplicedData = BaselineCorrectedData; % Make sure we can use the variable throughout
        
        
end

