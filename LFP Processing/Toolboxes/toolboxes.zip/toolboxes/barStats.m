%
% Custom function to bundle T-test/ANOVA into plots in a quick manner
%
% [P,ANOVATAB,STATS] = barStats(inputData,alphaValue, X values, Allow expansion, Normality check, Suppression of title)
%
% inputData - Data for testing; *Must* be arranged in rows for individuals and columns for groups/conditions
% alphaValue - p value
% xVals - [Optional] X-values of the groups, in cases of non-uniform placement
% Y limit expansion [Optional] - Whether to allow expansion of the Y limits (Default yes)
% Normality check - Whether to check for normality of groups and use nonparametric statistics if one or more groups are non-normal (Default no)
% Suppression of title - Whether to suppress the normal writing of stats data to the title (Useful for sriBoxPlot etc)
%
% P - Output p values of test
% ANOVATAB - Same as from ANOVA1 function
% STATS - Same as from ANOVA1 function
%


function [P,ANOVATAB,STATS] = barStats(inputData,alphaValue,varargin)
    if size(inputData,1) > 1 & size(inputData,2) > 1 & nansum( nansum( isnan(inputData) ) == size(inputData,1) ) < size(inputData,2)-1 %|| size(inputData,2) < 2 %"More than one row/individual, more than one column/group, at least two non-NaN columns"
        %####
        %Follow-on stats (Pre function form)
        %inputData = plotData;
        %Stats
        statsData = []; %The data
        statsDataGroups = []; %The groups
        for x = 1:size(inputData,2)
            %statsData = [statsData,overFlyPTTs{x}'];
            statsData = [statsData,inputData(:,x)']; %Assumption of double nature, not cells like original
            %statsDataGroups = [statsDataGroups,repmat(x,1,size(overFlyPTTs{x},1))]; 
            statsDataGroups = [statsDataGroups,repmat(x,1,size( inputData(:,x) ,1))]; %Test for differences between segments
            %statsDataGroups = [statsDataGroups, 1:1:size(inputData(:,x),1) )]; %Again, only valid for double arrays (Although not hard to build extra case)
                %Test for differences between flies?
        end
        usedTest = NaN;
        %Whether to check for normality
        %normalityChecked = NaN;
        normData = nan(1,size(inputData,2));
        if nargin >= 5 && isempty(varargin{3}) ~= 1 && varargin{3} == 1 %(exist('xvals', 'var'))
            %normalityChecked = 1;
            normData = [];
            for i = 1:size(inputData,2)
                [normData(i),~] = swtest(inputData(:,i));
            end
            if nansum(normData == 0) < 1
                [P,ANOVATAB,STATS]=anova1([statsData],[statsDataGroups], 'off');
                statCompare = multcompare(STATS, 'CType', 'bonferroni', 'display', 'off');
                usedTest = 'One-way ANOVA';
            else
                [P,ANOVATAB,STATS] = kruskalwallis([statsData],[statsDataGroups], 'off');
                statCompare = multcompare(STATS, 'CType', 'bonferroni', 'display', 'off');
                usedTest = 'Kruskal-Wallis';
            end
        else
            %normalityChecked = 0;
            [P,ANOVATAB,STATS]=anova1([statsData],[statsDataGroups], 'off');
            statCompare = multcompare(STATS, 'CType', 'bonferroni', 'display', 'off');
            usedTest = 'One-way ANOVA';
        end
        
        %%[P,ANOVATAB,STATS]=anova1([statsData],[statsDataGroups], 'off');
        %%statCompare = multcompare(STATS, 'CType', 'bonferroni', 'display', 'off');
        
        %Plotting
        %Generate X values
        if nargin >= 3 && isempty(varargin{1}) ~= 1 %(exist('xvals', 'var'))
            %xValsActive = xVals;
            xValsActive = varargin{1};
        else
            xValsActive = [ 1:nanmax(nanmax(statCompare(:,[1:2]))) ];
        end
        %Whether to override Y limits
        if nargin >= 4 && isempty(varargin{2}) ~= 1 %(exist('xvals', 'var'))
            %xValsActive = xVals;
            allowExpansion = varargin{2};
        else
            allowExpansion = 1; %Default allow
        end
        %statBaseHeight = nanmax(get(gca,'YLim'))*1.1; %Default altitude to put stat indication at
        statBaseHeight = nanmax( nanmean(inputData,1) )*1.1; %Default altitude to put stat indication at
        statInterval = 0.04*statBaseHeight; %How much space to leave between each group
        %statOccupation = nan(size(overFlyPTTs,2)*4,size(overFlyPTTs,2)); %WIll indicate what airspace is already occupied by a stat indicator (A convoluted system to cut down on having to make a very high series of indicators needlessly)
        %%statOccupation = nan(size(inputData,2)*size(inputData,2),size(inputData,2)); %Note: Will be ginormous with large number of groups
        statAltitude = statBaseHeight;
        statsDisplayed = 0;
        for i = 1:size(statCompare,1)
            if statCompare(i,6) < alphaValue
                %Check to see if airspace unoccupied
                %{
                %statAltitude = 1;
                statAltitude = statBaseHeight;
                while nansum( isnan(statOccupation(statAltitude,statCompare(i,1):statCompare(i,2))) ) ~= statCompare(i,2) - statCompare(i,1) + 1 %Will probs crash if exceeds number of targets
                    %statAltitude = statAltitude + 1;
                    statAltitude = statAltitude + 0.1*statBaseHeight;
                end
                %}
                %line([statCompare(i,1)+0.05,statCompare(i,2)-0.05],[statBaseHeight+statAltitude*statInterval,statBaseHeight+statAltitude*statInterval],'Color', [0.60,0.60,0.60], 'LineWidth', 1.5)
                %line([statCompare(i,1)+0.05,statCompare(i,2)-0.05],[statAltitude,statAltitude],'Color', [0.60,0.60,0.60], 'LineWidth', 1.5)
                line([xValsActive(statCompare(i,1))+0.05,xValsActive(statCompare(i,2))-0.05],[statAltitude,statAltitude],'Color', [0.60,0.60,0.60], 'LineWidth', 1.5)
                statAltitude = statAltitude + 0.05*statBaseHeight; %No checks for occupation
                %statOccupation(statAltitude,statCompare(i,1):statCompare(i,2)) = 1;
                statsDisplayed = statsDisplayed + 1;
            end
        end
        %ylim('auto') %Overrides fixed Y limits
        %Identify outliers
        %{
        for x = 1:size(overFlyPTTs,2)
            outlierStatus = isoutlier(overFlyPTTs{x}); %"More like...outFlier"
            if nansum(outlierStatus) > 0 %Outliers detected
                disp(['## Warning: Fly number/s ',num2str(find(outlierStatus == 1)'),' for Group ', num2str(targsOfInterest(x)) ,' detected to be outliers for PTT plot ##'])
            end
        end
        %}
        %Check if any sigs were plotted above visible space
        if statAltitude >= nanmax(get(gca,'YLim')) && statsDisplayed > 0
            %disp(['-# Caution: One or more significances plotted above figure Y limits #-'])
            if allowExpansion == 1
                yLim = get(gca,'YLim');
                ylim([ nanmin(yLim) , statAltitude*1.1 ])
                disp(['(Y limits had to be expanded)'])
            else
                disp(['-# Caution: One or more significances plotted above figure Y limits #-'])
            end
        end
        
        if nargin >= 6 && isempty(varargin{4}) ~= 1 && varargin{4} == 1
            disp('(Title suppressed)')
        else
            %Append stats info to title
            temp = get(gca,'title');
            %title( [temp.String,char(10),'(p<',num2str(alphaValue),'; One-way ANOVA w/ Bonff)'] );
            try
                %{
                if size(inputData,2) == 2 %ANOVA for two groups is effectively just a Student's T-test
                    title( [temp.String,char(10),'(p<',num2str(alphaValue),'; T-test)',char(10),'p = ',num2str(P)] );
                else
                    title( [temp.String,char(10),'(p<',num2str(alphaValue),'; One-way ANOVA w/ Bonff)',char(10),'ANOVA p = ',num2str(P)] );
                end
                %}
                title( [temp.String,char(10),'(p<',num2str(alphaValue),'; ' , usedTest,')' ,char(10),'p = ',num2str(P),char(10),'Normality: ',num2str(normData)] );
            catch
                %{
                if size(inputData,2) == 2
                    temp.String{3} = ['(p<',num2str(alphaValue),'; T-test)',char(10),'p = ',num2str(P)]; %For cases where title already has multiple rows
                else
                    temp.String{3} = ['(p<',num2str(alphaValue),'; One-way ANOVA w/ Bonff)',char(10),'ANOVA p = ',num2str(P)]; %For cases where title already has multiple rows
                end
                %}
                temp.String{size(temp.String,1)+1} = ['(p<',num2str(alphaValue),'; ', usedTest ,')' ,char(10),'p = ',num2str(P),char(10),'Normality: ',num2str(normData)]; %For cases where title already has multiple rows
                title( temp.String );
            end
        end
        
        inputData = []; %This is just in case of manual running
        %####
    else
        disp(['-# Cannot barStats with only one individual and/or group #-'])
        P = NaN; ANOVATAB = []; STATS = [];
    end
end