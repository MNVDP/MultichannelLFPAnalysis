%
% Custom function to turn otherwise barplot data into a boxplot
%
% sriBoxPlot( inputData, alpha value, exTicks, scatter width, colours, [nameStr,titleStr], suppress title, test normality )
%
% inputData - Data for Plotting; *Must* be arranged in rows for individuals and columns for groups/conditions
% 1 - alpha value - Float, p value (Var 1)
% 2 - exTicks [Optional] - (Var 2)
% 3 - scatter width [Optional] - How wide the jitter for the scatter points should be (Var 3)
% 4 - colours [Optional] - Group colours (Var 4)
% 5 - [nameStr,title] [Optional] - Figure and plot name override (Var 5)
% 6 - suppress title [Optional] - Whether to suppress the barStats added title or not
% 7 - test normality [Optional] - Whether to pass a yes (1) or no (0) to the barStats argument of testing normality (and using different tests)
% 8 - draw individual lines - Whether to draw lines between scatter individuals

function sriBoxPlot(inputData,varargin)

    %Name and title
    if nargin >= 8 && isempty(varargin{7}) ~= 1
        testNormality = varargin{7};
    else
        testNormality = 0; %Default no
    end

    %Name and title
    if nargin >= 7 && isempty(varargin{6}) ~= 1
       suppressTitle = varargin{6};
    else
        suppressTitle = 1;
    end

    %Name and title
    if nargin >= 6 && isempty(varargin{5}) ~= 1
       nameStr = varargin{5}{1};
       titleStr = varargin{5}{2};
    else
        try
            nameStr = get(gcf,'Name'); %Critical reliance on parent plot being the current graphics object
            titleStr = get(gca,'Title');  %Critical reliance on parent plot being the current graphics object
        catch
            nameStr = '';
            titleStr = '';
        end
    end

    %Scatter width
    if nargin >= 4 && isempty(varargin{3}) ~= 1
       scattWidth = varargin{3};
    else
        scattWidth = 0.2;
    end
    %Colours
    if nargin >= 5 && isempty(varargin{4}) ~= 1
       colours = varargin{4};
    else
        colours = repmat( [0,0,0], size(inputData,2) , 1 );
    end

    figure
    
    boxplot(inputData, 'Colors', colours)

    hold on
    
    %Rearrange colours if necessary
    if size(colours,1) ~= size(inputData,2)
        colours = colours';
    end
    
    scatCoords = nan( size(inputData,1) , size(inputData,2) );
    for col = 1:size(inputData,2)
        scatCoords(:,col) = col- (0.5*scattWidth) + rand( size(inputData,1) , 1 )*scattWidth;
        %scatter( col- (0.5*scattWidth) + rand( size(inputData,1) , 1 )*scattWidth ,...
        %    inputData(:,col), [],colours(col,:), 'filled' )
        scatter( scatCoords(:,col) ,...
            inputData(:,col), [],colours(col,:), 'filled' )
    end
    %Draw indiv lines
    if nargin >= 9 && isempty(varargin{8}) ~= 1 && varargin{8} == 1
        for indiv = 1:size(scatCoords,1)
            line( scatCoords(indiv,:) , inputData(indiv,:) , 'Color', [0.66,0.66,0.66] )
            %Note: Could probably extend this to incorporate colours, if so desired (with line segments and a subloop)
        end
    end
    
    grid on

    %Scatter width
    if nargin >= 3 && isempty(varargin{2}) ~= 1
       xticklabels( varargin{2} );
    end

    alphaValue = varargin{1};
    %barStats(inputData,alphaValue,[],[],1,1);
    %[P, ANOVATAB, STATS] = barStats(inputData,alphaValue,[],[],1,suppressTitle);
    [P, ANOVATAB, STATS] = barStats(inputData,alphaValue,[],[],testNormality,suppressTitle);
    %disp(STATS)
    
    %disp(titleStr.String)
    %disp(nameStr)
    try
        title(titleStr.String) %Automated detection case
    catch
        title(titleStr) %Manual specification/Failure of detection case
    end

    set(gcf,'Name', [nameStr,' boxplot'])








end